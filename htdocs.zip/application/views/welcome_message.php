<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<h1>Welcome To App, We will update Soon...</h1>
<h2>Authorised User's Can Login here...</h2><a href="<?php echo base_url(); ?>login">Login here</a>
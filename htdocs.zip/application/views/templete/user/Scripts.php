<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url(); ?>Content/Backend/js/jquery.js"></script>
    <script src="<?php echo base_url(); ?>Content/Backend/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo base_url(); ?>Content/Backend/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo base_url(); ?>Content/Backend/js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo base_url(); ?>Content/Backend/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>Content/Backend/js/respond.min.js" ></script>

    <!--common script for all pages-->
    <script src="<?php echo base_url(); ?>Content/Backend/js/common-scripts.js"></script>


  </body>
</html>
